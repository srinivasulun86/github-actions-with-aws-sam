import { Tabs } from "../types/courses";

export const TabsList: Tabs[] = [
  "Course Info",
  "Resources",
  "Assignments",
  "Projects",
];
